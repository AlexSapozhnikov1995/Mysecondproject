package basics;

public class Palindrome {
    public static void main(String [] args){
        Palindrome pn = new Palindrome();

        if(pn.isPalindromePermutation("ALEXANDER")){
            System.out.println("Palindrome");
        } else {
            System.out.println("Not Palindrome");
        }
    }
    public boolean isPalindromePermutation(String s){
        int i = s.length()-1;
        int j=0;
        while(i > j) {
            if(s.charAt(i) != s.charAt(j)) {
                return false;
            }
            i--;
            j++;
        }
        return true;
    }
}

